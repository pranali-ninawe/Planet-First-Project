const cors = require("cors");

const http   = require('http');
const https = require('https');
const fs = require('fs');

const privateKey  = fs.readFileSync('key.pem', 'utf8');
const certificate = fs.readFileSync('cert.pem', 'utf8');

const stripe = require("stripe")("sk_test_CoSCJ4niDOCgcXILgZm57juu00NV2UgtHx");
const uuid = require("uuid/v4");

const express = require("express");
const emailer = require('./emailer');


const credentials = {key: privateKey, cert: certificate};
const app = express();

app.use(express.json());
app.use(cors());

app.get("/", (req, res) => {
    res.send("Add your Stripe Secret Key to the .require('stripe') statement!");
});

app.post("/checkout", async (req, res) => {
    console.log("Request:", req.body);

    let status;
    let charge;
    try {
        const { campaign, token } = req.body;

        const customer = await stripe.customers.create({
            email: token.email,
            source: token.id
        });

        const idempotency_key = uuid();
        charge = await stripe.charges.create(
            {
                amount: campaign.donation * 100,
                currency: "usd",
                customer: customer.id,
                receipt_email: token.email,
                description: `Donated to ${campaign.name}`,
                shipping: {
                    name: token.card.name,
                    address: {
                        line1: token.card.address_line1,
                        line2: token.card.address_line2,
                        city: token.card.address_city,
                        country: token.card.address_country,
                        postal_code: token.card.address_zip
                    }
                }
            },
            {
                idempotency_key
            }
        );
        console.log("Charge:", { charge });
        status = "success";
        emailer.sendEmail(charge.receipt_email);
    } catch (error) {
        console.error("Error:", error);
        status = "failure";
    }

    if(status == "success"){
        res.json({status, charge });
    }else{
        res.json({status });
    }
});


var httpServer = http.createServer(app);
var httpsServer = https.createServer(credentials, app);

httpServer.listen(8080);
httpsServer.listen(8443);

