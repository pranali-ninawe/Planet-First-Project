import React, { Component } from 'react';
import '../styles/news.css';

class News extends Component {
    constructor(props){
        super(props);
        this.state = {
            articles: []
    }
}

    componentDidMount() {
        fetch('https://newsapi.org/v2/everything?qInTitle=("Climate")&from=2019-11-14&sortBy=publishedAt&language=en&apiKey=308dd344ddfb43e6bc1e857546a2c06d')
            .then((response) => {
                return response.json();
            })
            .then((myJson) => {
                this.setState({
                    articles: myJson.articles
                });
            });
            }


    render() {
        console.log(this.state);
        return(
            <div className="News">
                {this.state.articles.map((item,index) => 
                    {
                        if(!(item.urlToImage == null) && !(item.urlToImage === "null"))
                        {
                            return (
                                <div className="news-wrapper">
                                    <h2>
                                        {item.title}   
                                    </h2>
                                    <b className="news-author">{item.author}</b>
                                    <div className="img-wrapper">
                                    <img className="news-image" src={item.urlToImage} alt="Unavailable"/>
                                    </div>
                                    <p className="news-content">
                                        {item.content}
                                        <br></br><a className="news-url" href={item.url}>Read More</a><br></br>
                                    </p>
                                </div>
                            );
                        }
                        return (<div></div>);
                    
                    }
                )}
            </div>
        )
    }
}

export default News;
