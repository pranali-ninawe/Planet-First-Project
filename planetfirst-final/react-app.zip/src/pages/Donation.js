import React from "react";
import DonationWrapper from "../components/DonationWrapper"

const Donation = () => {
  return (
  <DonationWrapper/>
  );


};

export default Donation;