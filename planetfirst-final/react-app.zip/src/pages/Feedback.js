import React from "react";

const Feedback = () => {
  return (
    <div>
      <p>Feedback</p>
    </div>
  );
};

export default Feedback;