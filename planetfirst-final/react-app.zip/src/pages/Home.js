import React from 'react';
import TwitterFeed from '../components/TwitterFeed'


const Home = () => {
  return (
    <div className="twitter_wrapper">
      <TwitterFeed />
    </div>
  );
};


export default Home;
