import React from 'react'


const SupportPlanetFirst = () =>{
    return(
        <div className="support_wrapper">
        <h1 className="support_title">SUPPORT PLANET FIRST</h1>
        <p>Your contribution will help <strong>PLANET FIRST</strong> spread the truth about climate change and the importance of implementing solutions together.
        Help us educate the public and power a global grassroots network devoted to solving the climate crisis.</p> 
        </div>
    )
}

export default SupportPlanetFirst