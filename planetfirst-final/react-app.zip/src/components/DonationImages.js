const DonationImages = [
    { id: 1, src: 'images/reforestation.jpg', title: 'Reforestation'},
    { id: 2, src: 'images/cleanupocean.jpg', title: 'Cleaning up oceans'},
    { id: 3, src: 'images/recycling.jpg', title: 'Recycling'},
    { id: 4, src: 'images/waterfoodsecurity.jpg', title: 'Water and Food Security'},
    { id: 5, src: 'images/cleangreencity.jpg', title: 'Clean Energy and Green Cities'},
    { id: 6, src: 'images/fightingfossilfuels.jpg', title: 'Fighting Fossil Fuels'},
    { id: 7, src: 'images/endangered animals.jpg', title: 'Endangered Animals'},
    { id: 8, src: 'images/volcano.jpg', title: 'Volcanic Eruptions'},
  ];




  export default DonationImages